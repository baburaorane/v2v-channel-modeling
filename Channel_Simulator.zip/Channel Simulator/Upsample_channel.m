% A function to increase the sampling rate of the channel coefficients from
% 1/T_d to 1/Tc

% Inputs :  T_d  Original Sampling interval (Inversly proportional to the doppler frequency)
%           T_c  Desired  Sampling interval (equal to 1/the bandwidth)
%           A_d  N_e X M X L matrix containing the spatially correlated sequences of the ith TDP as its rows (upsampling is performed on each row) 
%           t_end  Last time instant on the time axis
%           F_a  LX1 vector containing the Power Delay Profile

% Output:   A_c  N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function  [A_c,t]=Upsample_channel(T_d,T_c,t_end,A_d,F_a)

% Upsampling parameters
upsampling_factor=round(T_d/T_c);       % Required upsampling factor
I_p=32;                                 % Upsampling factor for the classic interpolator (zero-padding+Low pass filtering) 
I_c=upsampling_factor/I_p;                                                         % Upsampling factor for the cubic interpolator
t=0:T_c:t_end;                                                                     % vector containing time instants of the channel coefficients
t_d=0:T_d:t_end;                                                                   % vector containing time instants of the time correlated channel cooefficents
t_up=linspace(-1*T_d*((I_p-1)/I_p),t_end+T_d*((I_p-1)/I_p),I_p*length(t_d)+I_p-1); % vector containing the time instants corresponding to the first stage of upsampled coefficients (zero-padded)     
[N_e,M,L]=size(A_d);
%-------------------------------------------------------
% Construct the DAP
% Two stage interpolation
for i=1:L
    for k=1:N_e
        v(i,:)=A_d(k,:,i);
        if M==1 
            v_up1(i,:)=(upsample(v(i,:),I_p)).';        %
        else
            v_up1(i,:)=(upsample(v(i,:),I_p));
        end
        v_up(i,:)=[zeros(1,I_p-1),v_up1(i,:)];          % Add zeros to the begining of the sequence to avoid truncation effects while filtering
        [B,A]=butter(4,1/(I_p));                        % butterworth low pass filter with normalized cutoff frequency 1/I_c
        v_classic(i,:)=filtfilt(B,A,v_up(i,:)*I_p);     % Normalize power by multiplaying by I_p 
        v_c(i,:)=spline(t_up,v_classic(i,:),t);         % Interpolated sequence using cubic splines
        A_c(k,:,i)=v_c(i,:);
    end
    norm_s=norm(A_c(:,:,i),'fro').^2/(N_e*length(t));                    % Average power within each subpath
    A_c(:,:,i)=sqrt(F_a(i))*A_c(:,:,i)/sqrt(norm_s);
end

%-------------------------------------------------------
% Check the interpolation function
TDP=1;                   % Select the TDP to plot                      
% figure
% plot(t_d,abs(v(TDP,:)))
% hold on
% plot(t_up,abs(v_up(TDP,:)),'r')
% plot(t_up,abs(v_classic(TDP,:)),'m')
% plot(t,abs(v_c(TDP,:)),'k--')
% legend('Low-sampled coefficients','Zero-padded Channel coefficents','classic interpolation','Two stage interpolation')
% xlabel('time (seconds)')
% ylabel(['Absolute value of the Channel coefficients of the ',num2str(TDP),'th TDP'])
%-------------------------------------------------------
figure
style=['k--';'r-.'; 'b  ';'g: ';'m--';'y-.'];
labels=[];
for i=1:L
    plot(t*1e3,10*log10(abs(v_c(i,:))),style(i,:));
    hold on
    labels=[labels;'path ',num2str(i-1)];
end
legend(labels)
xlabel('Time (msec)')
ylabel('Magnitude of channel coefficients of the TDPs')
grid on