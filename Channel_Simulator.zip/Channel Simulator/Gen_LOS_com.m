% A function to introduce LOS propagation to a random channel model
% Note that LOS propagation effect is added only to the first tap of the FIR filter structure
% Inputs
%           A_c     N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients
%           Theta_LOS  LOS arrival angle
%           P_LOS   fraction of power arriving within LOS component
%           T_c     Desired  Sampling interval (equal to 1/the bandwidth)
%           t_end   Last time instant on the time axis       
%           f_d     Doppler frequency
%           C_channel Channel covariance matrix of each tap


function [A,C_channel]=Gen_LOS_com(A_c,Theta_LOS,P_LOS,T_c,t_end,r,lamda,f_d,C_channel)

[N_e,m,L]=size(A_c);
t=0:T_c:t_end;                                                                % vector containing time instants of the channel coefficients
K=2*pi*[cos(Theta_LOS),sin(Theta_LOS)]/lamda;                                 % wave vector corresponding to LOS DOA
v=exp(-j*K*r.').';                                                            % array steering vector at LOS DOA 
epsi=rand*2*pi;                                                               % The doppler angle random and constant
A_LOS=sqrt(P_LOS)*v* exp(j*2*pi*f_d*t*cos(epsi));
A=A_c;
A(:,:,1)=A(:,:,1)+A_LOS;                                                      % Add LOS component
C_channel(:,:,1)=C_channel(:,:,1)+P_LOS*v*v';                                 % Add LOS component to covariance matrix
