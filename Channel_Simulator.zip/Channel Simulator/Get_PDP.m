% A function to Generate the power delay profile (PDP)
% The PDP is assumed exponential and the Power Angle 

% Inputs:
%           B  Signal bandwidth
%           T_m  Mean delay of the PDP 
%           L    Length of TDL
%           PDP  the profile,'Exp' for exponential
%           P_LOS power contained in the LOS component

function    F_a=Get_PDP(B,T_m,L,PDP,P_LOS)

if PDP=='Exp'
    F_a=(1-exp(-1/(B*T_m)))*exp(-(0:L-1)/(B*T_m));                 % Exponential power delay profile
    F_a=(1-P_LOS)*F_a/norm(F_a,1);                                           % Power Normalization 
end

