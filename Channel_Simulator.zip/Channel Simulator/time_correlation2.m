% A function to generate N_e independent sequences with specific time autocorrelation
% function
% Inputs : N_e  Number of independent sequences
%          M    length of each sequence
%          L    Number of TDP (taps in the FIR model)
%          f_d  The doppler frequency f_c*v/c
%          K    Order of the IIR time correlation filter
%          N_f  Number of frequency points used to pproximate the response

% Output : Y  N_e X M X L where the ith N_e X M matrix contains the sequences of the ith TDP as its rows
clear all
% function Y=time_correlation(N_e,M,L,f_d,K,N_f )
f_d=100
K=5
N_f=256

% Desired power spectral density
T=1/(3*f_d);                       % Sampling interval
f=linspace(-1/(2*T),1/(2*T),N_f+1); % frequency grid
for i=1:length(f)                 
    if abs(f(i))<=f_d
        S(i)=2/(sqrt((2*pi*f_d*T).^2-(2*pi*f(i)*T).^2));
    else
        S(i)=0;
    end
end


% Iterative algorithm to design the filter coefficients
%Initialization
a_k=randn(K-1,1);                      % Dinimunator coefficients         %a_k(0) is fixed as 1
b_k=randn(K,1);                      % Numerator coefficients     

% 
%  a_k=[1;1.7428;2.3339;1.34276;0.59552];
%  b_k=[0.71724;1.70502;2.25142;1.51287;0.53630]
figure

H_k=eye(2*K-1,2*K-1);                    % Inverse of the Hessian
epsrom=1e-7;                          % stopping criteria on the norm of the gradient
Max_iterations=50;                 % maximum number of iterations
for iter=1:Max_iterations
    iter
    % Calculate gradiant
    g_k=zeros(2*K-1,1);
    for i=1:length(f)
        v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
        H_f(i)=(b_k.'*v_i)/([1;a_k].'*v_i);       %transfer function at frequency f_i
        g_k(1:K)=g_k(1:K)+ (2*(abs(H_f(i)).^2-S(i)) *(2*v_i*v_i'*b_k)/([1;a_k].'*v_i*v_i'*[1;a_k]));
        g_k(K+1:2*K-1)=g_k(K+1:2*K-1)-(2*(abs(H_f(i)).^2-S(i))*(b_k.'*v_i*v_i'*b_k)* (2*v_i(2:K)*v_i(2:K)'*[a_k])/(([1;a_k].'*v_i*v_i'*[1;a_k]).^2));
        
    end
    g_k=real(g_k);
    norm(g_k)
    if norm(g_k)<=epsrom
        break
    else % Do another iteration 
        s_k=-1*inv(H_k)*g_k;                       % Descent direction
        % Line search to find step size (Back tracking)
        alpha=0.1;
        beta=0.5;
        t=1;
        cost_f= sum(((abs(H_f)).^2-S).^2);
        b_k_d=b_k+t*s_k(1:K);
        a_k_d=a_k+t*s_k(K+1:2*K-1);
        for i=1:length(f)
            v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
            H_f_d(i)=(b_k_d.'*v_i)/([1;a_k_d].'*v_i);       % transfer function along descent direction with step t
        end
        cost_f_d= sum(((abs(H_f_d)).^2-S).^2);
        while cost_f_d > cost_f+ (alpha*t*g_k.'*s_k)
            t=beta*t;                               % Reduce step
            b_k_d=b_k+t*s_k(1:K);
            a_k_d=a_k+t*s_k(K+1:2*K-1);
            for i=1:length(f)
                v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
                H_f_d(i)=(b_k_d.'*v_i)/([1;a_k_d].'*v_i);    % transfer function along descent direction with step t
            end
            cost_f_d= sum(((abs(H_f_d)).^2-S).^2);
        end
        
        % compute new gradiant
        g_k_d=zeros(2*K-1,1);
        for i=1:length(f)
            v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
            H_f(i)=(b_k_d.'*v_i)/([1;a_k_d].'*v_i);       %transfer function at frequency f_i
            g_k_d(1:K)=g_k_d(1:K)+ (2*(abs(H_f(i)).^2-S(i))*2*v_i*v_i'*b_k_d/([1;a_k_d].'*v_i*v_i'*[1;a_k_d]));
            g_k_d(K+1:2*K-1)=g_k_d(K+1:2*K-1)-(2*(abs(H_f(i)).^2-S(i))*(b_k_d.'*v_i*v_i'*b_k_d)*(2*v_i(2:K)*v_i(2:K)'*a_k_d)/([1;a_k_d].'*v_i*v_i'*[1;a_k_d]).^2);
        end
        %         % Update approximate inverse Hessian matrix and estimates 
        p_k=([b_k_d;a_k_d]-[b_k;a_k]);
        q_k=g_k_d-g_k;
        %B_k = B_k +((1 + q_k'*B_k*q_k)/(q_k'*p_k ))* (p_k*p_k'/(p_k'*q_k)) - ((p_k*q_k'*B_k + B_k*q_k*p_k')/(q_k'*p_k));
%         H_k = H_k +((q_k*q_k')/(q_k'*p_k)) - ((H_k*p_k*p_k'*H_k)/(p_k'*H_k*p_k));
        
        
        a_k=a_k_d;
        b_k=b_k_d;
        
        plot(f(1:length(f)),S,'r')
        hold on
        plot(f(1:length(f)),abs(H_f_d).^2)
    end
    
end
figure
plot(f(1:length(f)),S,'r')
hold on
plot(f(1:length(f)),abs(H_f_d).^2)
% Perform the filtering operation  to temporally colour the noise sequences
Y=[];







