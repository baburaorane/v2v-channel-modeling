% A function to generate an IIR filter with prespecified magnitude frequency response (PSD)
% Inputs         S: Desired power spectral density
%                K  Order of the IIR time correlation filter
%                f frequency grid
%                T Sampling interval


% Outputs       a_k  Dinimunator coefficients
%               b_k  Numerator coefficients



function [a_k,b_k]=Get_filter(S,K,f,T)
Max_iterations=50;                   % maximum number of Quasi-Newton iterations

%Initialization
a_k=randn(K,1);                      % Dinimunator coefficients
b_k=randn(K,1);                      % Numerator coefficients
B_k=eye(2*K,2*K);                    % Inverse of the Hessian

epsrom=1e-7;                          % stopping criteria on the norm of the gradient
for iter=1:Max_iterations
    % Calculate gradiant
    g_k=zeros(2*K,1);
    for i=1:length(f)
        v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
        H_f(i)=(b_k.'*v_i)/(a_k.'*v_i);       %transfer function at frequency f_i
        g_k(1:K)=g_k(1:K)+ (2*(abs(H_f(i)).^2-S(i)) *(2*v_i*v_i'*b_k)/(a_k.'*v_i*v_i'*a_k));
        g_k(K+1:2*K)=g_k(K+1:2*K)-(2*(abs(H_f(i)).^2-S(i))*(b_k.'*v_i*v_i'*b_k)* (2*v_i*v_i'*a_k)/((a_k.'*v_i*v_i'*a_k).^2));
    end
    g_k=real(g_k);
    if norm(g_k)<=epsrom
        break
    else % Do another iteration 
        s_k=-1*(B_k)*g_k;                       % Descent direction
        % Line search to find step size (Back tracking)
        alpha=0.1;
        beta=0.5;
        t=1;
        cost_f= sum(((abs(H_f)).^2-S).^2);
        b_k_d=b_k+t*s_k(1:K);
        a_k_d=a_k+t*s_k(K+1:2*K);
        for i=1:length(f)
            v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
            H_f_d(i)=(b_k_d.'*v_i)/(a_k_d.'*v_i);       % transfer function along descent direction with step t
        end
        cost_f_d= sum(((abs(H_f_d)).^2-S).^2);
        while cost_f_d > cost_f+ (alpha*t*g_k.'*s_k)
            t=beta*t;                               % Reduce step
            b_k_d=b_k+t*s_k(1:K);
            a_k_d=a_k+t*s_k(K+1:2*K);
            for i=1:length(f)
                v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
                H_f_d(i)=(b_k_d.'*v_i)/(a_k_d.'*v_i);    % transfer function along descent direction with step t
            end
            cost_f_d= sum(((abs(H_f_d)).^2-S).^2);
        end
        
        % compute new gradiant
        g_k_d=zeros(2*K,1);
        for i=1:length(f)
            v_i=exp(-j*2*pi*f(i)*(0:K-1)*T).';
            H_f(i)=(b_k_d.'*v_i)/(a_k_d.'*v_i);       %transfer function at frequency f_i
            g_k_d(1:K)=g_k_d(1:K)+ (2*(abs(H_f(i)).^2-S(i))*2*v_i*v_i'*b_k_d/(a_k_d.'*v_i*v_i'*a_k_d));
            g_k_d(K+1:2*K)=g_k_d(K+1:2*K)-(2*(abs(H_f(i)).^2-S(i))*(b_k_d.'*v_i*v_i'*b_k_d)*(2*v_i*v_i'*a_k_d)/(a_k_d.'*v_i*v_i'*a_k_d).^2);
        end
        % Update approximate inverse Hessian matrix and estimates 
        p_k=([b_k_d;a_k_d]-[b_k;a_k]);
        q_k=g_k_d-g_k;
%         B_k = B_k +((1 + q_k'*B_k*q_k)/(q_k'*p_k ))* (p_k*p_k'/(p_k'*q_k)) - ((p_k*q_k'*B_k + B_k*q_k*p_k')/(q_k'*p_k));
        %H_k = H_k +((q_k*q_k')/(q_k'*p_k)) - ((H_k*p_k*p_k'*H_k)/(p_k'*H_k*p_k));
        a_k=a_k_d;
        b_k=b_k_d;
    end
end
% Check
% Plot PSD of the designed filter
figure
plot(f(1:length(f)),10*log10(S),'r')
hold on
plot(f(1:length(f)),10*log10(abs(H_f_d).^2))
legend('Desired power spectral density','Squared magnitude response of the filter')
xlabel('frequency')
ylabel('Response (dB)')