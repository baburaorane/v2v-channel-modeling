% A function to spatially correlate independent data streams
% Profile (PAP) can be chosen as Uniform or Laplacian
% Inputs:   Y  N_e X M X L matrix where the ith N_e X M matrix contains the sequences of the ith TDP as its rows
%           L  number of taps in the TDL model
%           r  N_e X 2 vector containing the sensor location in the (x,y) plane
%           lamda  wavelength of the incident wave
%           Theta_LOS  LOS arrival angle
%           Theta_s L X 1 vector containing the corresponding angular spread of each TDP
%                   Note that the angles are measured in radians and with respect to the x-axis 
%           PAP  string containing the PAP of the TDPs ; 'U' for uniform , 'L' for Laplacian

% Output    A  N_e X M X L matrix containing the spatially correlated sequences of the ith TDP as its rows
%           C_channel N_e X N_e X L channel covariance matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [A,C_channel]=spatial_correlation(Y,r,lamda,Theta_i,Theta_s,PAP,F_a)
[N_e,M,L]=size(Y);
for i=1:L
    %  Construct the PAP
    if PAP=='U'
        Theta_grid=Theta_i(i)-(Theta_s(i)/2):0.1*pi/180:Theta_i(i)+(Theta_s(i)/2);
        f_theta=ones(1,length(Theta_grid))/length(Theta_grid);                       % Uniform PAP
        Theta_spacing=Theta_grid(2)-Theta_grid(1);
    elseif PAP=='L'
        Theta_grid=Theta_i(i)-(6*Theta_s(i)):0.1*pi/180:Theta_i(i)+(6*Theta_s(i));   %Laplacian PAP
        f_theta=(1/(2*Theta_s(i)))*exp(-1*abs(Theta_grid-Theta_i(i))/Theta_s(i));
        f_theta=f_theta/norm(f_theta,1);
        Theta_spacing=Theta_grid(2)-Theta_grid(1);
    end
    % Construct the spatial covariance matrix for the ith TDP 
    R_v(1:N_e,1:N_e,i)=zeros(N_e,N_e);                         % Initialize the spatial covariance matrix
    for theta_index=1:length(Theta_grid)
        K=2*pi*[cos(Theta_grid(theta_index)),sin(Theta_grid(theta_index))]/lamda;     % wave vector
        v=exp(-j*K*r.').';                                                            % array steering vecto 
        R_v(1:N_e,1:N_e,i)=R_v(1:N_e,1:N_e,i)+f_theta(theta_index)*v*v';
    end
    C(1:N_e,1:N_e,i)=R_v(1:N_e,1:N_e,i);
    [QC,VC]=eig(C(1:N_e,1:N_e,i));
    A(:,:,i)=QC*sqrt(VC)*Y(:,:,i);                             % The spatially coloured output vectors of the ith TDP   
    norm_s=norm(A(:,:,i),'fro').^2/(N_e*M);                    % Average power within each subpath
    A(:,:,i)=sqrt(F_a(i))*A(:,:,i)/sqrt(norm_s);
    C_channel(:,:,i)=F_a(i)*C(1:N_e,1:N_e,i);
%--------------------------------------

end