% A function to plot a polar plot of the directivity pattern at a certain
% frequency corresponding to each path
% 
%Inputs   A_c    N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients
%         T_c    Sampling interval
%         t_end  Last time instant on the time axis
%         t      M*T_d/T_c vector containing the corresponding time instants
%         t_plot N_t X 1 vector containing the time instant at which the pattern is plotted
%         r      location vector containing the locations of the array elements
%         f      frequency at which the directivity pattern is plotted


% Output  G_p     N_theta X L matrix containing the directivity pattern corresponding to each path
function G_p=directivity_polar(A_c,T_c,t_end,t_plot,r,f)

t=0:T_c:t_end;                                         % vector containing time instants of the channel coefficients
[N_e,N,L]=size(A_c);
Theta_grid=linspace(0,360,181)*pi/180;                 % Angular grid used to plot the array response
c=3e8;                                                 % propagation speed of the wave

% Extract the array coefficients
Index=find(t==t_plot);
for k=1:L
    C(1:N_e,k)=A_c(:,Index,k);
end
%-------------------------------------------------------
for i=1:length(Theta_grid)
    theta=Theta_grid(i);
    K=2*pi*(f)*[cos(theta),sin(theta)]/c;              % wave vector (Passband frequency is used f+f_c)
    v=exp(-j*K*r.').';                                 % Narrowband array steering vector (received by sensors)
    v=v./norm(v);
    for k=1:L                                          % Wideband steering vector
        w=C(:,k);
        w=w/norm(w);                                   % Normalize weight vector 
        G_p(i,k)=w'*v;
    end
end
%-------------------------------------------------------
figure
style=['k--';'r-.'; 'b  '];
labels=[];
for i=1:L
    polar(Theta_grid.',abs(G_p(:,i)).^2,style(i,:))
    hold on
    labels=[labels;'path ',num2str(i-1)];
end
legend(labels)

