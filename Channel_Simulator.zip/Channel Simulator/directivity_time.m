% A function to plot the time directivity pattern at a certain frequency
% versus different time instants
%Inputs   A_c    N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients
%         T_c    Sampling interval
%         t_end  Last time instant on the time axis
%         t      M*T_d/T_c vector containing the corresponding time instants
%         t_plot N_t X 1 vector containing the time instants at which the pattern is plotted
%         r      location vector containing the locations of the array elements
%         B      Bandwidth
%         f frequency at which the directivity pattern is plotted


% Output  G      N_theta X N_t matrix containing the directivity pattern
function G_t=directivity_time(A_c,T_c,t_end,t_plot,r,B,f)

t=0:T_c:t_end;                                         % vector containing time instants of the channel coefficients
[N_e,N,L]=size(A_c);
Theta_grid=linspace(0,360,181)*pi/180;                 % Angular grid used to plot the array response
c=3e8;                                                 % propagation speed of the wave

% Extract the array coefficients at each time instant
for t_ind=1:length(t_plot)
    t_sample=t_plot(t_ind);
    Index=find(t==t_sample);
    for k=1:L
        C(1:N_e,k)=A_c(:,Index,k);
    end
    w=vec((C));                                            % Beamforming vector matched to channel coefficients                                        
    w=w./norm(w);                                          % Normalize weight vector
    for i=1:length(Theta_grid)
        theta=Theta_grid(i);
        K=2*pi*(f)*[cos(theta),sin(theta)]/c;              % wave vector (Passband frequency is used f+f_c)
        v=exp(-j*K*r.').';                                 % Narrowband array steering vector (received by sensors)
        a=kron(exp(-j*2*pi*f*(0:L-1)*T_c).',v);            % Wideband steering vector
        a=a./norm(a);
        G_t(i,t_ind)=w'*a;
    end
end

%-------------------------------------------------------
% Plot the Directivity pattern image
G_abs=20*log10(abs(G_t));                                 % Absolute value of the directivity pattern in decibels
% Plot the 2D image
figure
colormap('gray');
G_image=(G_abs);
%imagesc(180*Theta_grid/pi,t_plot,(G_image.'));
contourf(180*Theta_grid/pi,t_plot*1e3,(G_image.'));
ylabel('Time (msec)')
xlabel('Azimuth angle (degrees)')
colorbar('vert')


G_abs=20*log10(abs(G_t));                                 % Absolute value of the directivity pattern in decibels
% Plot the 2D image
figure
colormap('gray');
G_image=(G_abs);
imagesc(180*Theta_grid/pi,t_plot*1e3,(G_image.'));
%contourf(180*Theta_grid/pi,t_plot,(G_image.'));
ylabel('Time (msec)')
xlabel('Azimuth angle (degrees)')
colorbar('vert')
