% A function to return the locations of an M-sensor planar antenna array
% Inputs: N_e    Number of antenna elements
%         d      spacing between elements
%         Shape  string defining the geomtry of the array; 'L' for linear, 'C' for circular

% Output: r      N_e X 2 matrix containing the x and y coordinates of each sensor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function r=Get_sensor_loc(N_e,d,Shape)
if Shape=='L'        %linear structure (place array along the Y-axis with the coordinate center in the center of the array)
    hlf_apert=(N_e-1)*d/2;                 % Half the array aperture
    r=[zeros(N_e,1),linspace(-1*hlf_apert,hlf_apert,N_e).'];
elseif Shape=='C'    %circular structure
    r=[];
    theta=2*pi/(N_e);  
    alpha=(pi-theta)/2;
    radius=d*sin(alpha)/sin(theta);
    theta_element=0;
    for i=1:N_e
        r=[r;d*[cos(theta_element),sin(theta_element)]];
        theta_element=theta_element+theta;
    end
elseif Shape=='r'
    thetas=rand(N_e,1)*2*pi;
    dist=rand(N_e,1)*d;
    r=[];
    for i=1:N_e
        r=[r;d*[cos(thetas(i)),sin(thetas(i))]];
    end
end

         

