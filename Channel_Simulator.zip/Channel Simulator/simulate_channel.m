% A program/function to simulate a time-varying frequency slective wireless SIMO Channel

% Inputs
% Signal Parameters
                    % f_d                           % Doppler frequency
                    % B                             % Bandwidth of the transmitted signal
                    % f_c=1e9                       % Center frequency
                    % t_end=0.05                    % Last time instant on the time axis       
% Propagation Environment
                    % L                             % Number of TDPs
                    % T_m                           % Mean delay of the exponential PDP
                    % PAP                           % Power angle profile; 'U' for uniform, 'L' for Laplacian 
                    % Theta_i                       % L X 1 vector containing the mean angle of arrival of each time diffrentiable path (TDP)
                    % Theta_s                       % L X 1 vector containing the corresponding angular spread of each TDP 
                    % Theta_LOS                     % LOS arrival angle
                    % P_LOS                         % fraction of power arriving within LOS component
                    % PDP                           % Power delay profile; 'Exp' for exponential
% Array Parameters
                    % N_e                           % Number of antenna elements
                    % Array_shape                   % Antenna array configuration; 'C' for circular, 'L' for linear                          
                    % d                             % Spacing between array elements

                    
% Outputs 
%                    A_c  N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  function [Channel_coeff,C_channel]=simulate_channel(L,B,f_c,t_end,N_e,Array_shape,d,PDP,T_m,PAP,Theta_i,Theta_s,Theta_LOS,P_LOS,f_d)
% 
% Signal Parameters
close all
velocity=200                            % Velocity in Km/hr
%B=1.2288e6;                            % Bandwidth of the transmitted signal
B=(5.925-5.85)*1e9                      % Bandwidth of the transmitted signal
f_c=((5.925+5.85)/2)*1e9;               % Center frequency
%f_c=1e9;                               % Center frequency

veloc=velocity*1000/3600;               % Doppler frequency
f_d=round(veloc*f_c/3e8);                                % Doppler frequency
f_d=1100


t_end=4e-3;                             % Last time instant on the time axis
T_d=1/(3*f_d);                          % The sampling interval for the time correlation filter
T_c=1/(2*B);                            % The sampling interval of the channel coefficients
lamda=3e8/f_c;                          % wavelength

% Propagation Environment
L=3                                     % Number of TDPs
T_m=2/B;                                % Mean delay of the exponential PDP
PAP='U';                                 % Power angle profile; 'U' for uniform, 'L' for Laplacian 
Theta_i=[90;150;270]*pi/180;            % L X 1 vector containing the mean angle of arrival of each time diffrentiable path (TDP)
Theta_s=[5,4,2]*pi/180;                % L X 1 vector containing the corresponding angular spread of each TDP
Theta_LOS=10*pi/180;                    % LOS arrival angle
P_LOS=0.0;                              % fraction of power arriving within LOS component
PDP='Exp';                              % Power delay profile

% Array Parameters
N_e=8;                                  % Number of antenna elements
Array_shape='C';                         % Antenna array configuration; 'C' for circular, 'L' for linear                          
d=lamda/2;                              % Spacing between array elements
% % 
%-------------------------------------------------------
T_d=1/(3*f_d);                          % The sampling interval for the time correlation filter
T_c=1/(2*B);                            % The sampling interval of the channel coefficients
lamda=3e8/f_c;                          % wavelength
%-------------------------------------------------------
% Call different channel functions
Y=time_correlation(N_e,L,f_d,T_d,t_end);                                    % Introduce time correlation due to motion (doppler)
r=Get_sensor_loc(N_e,d,Array_shape);            
F_a=Get_PDP(B,T_m,L,PDP,P_LOS);                                           % Get power delay profile
[A_s,C_channel]=spatial_correlation(Y,r,lamda,Theta_i,Theta_s,PAP,F_a);               % Introduce spatial correlation 
if t_end==0                                                               % Channel coeeficients at only one moment (No nonstationary effct)
    A_c=A_s;                          
else [A_c,t]=Upsample_channel(T_d,T_c,t_end,A_s,F_a);                         % Increase sampling rate to match the bandwidth of the system
end
[Channel_coeff,C_channel]=Gen_LOS_com(A_c,Theta_LOS,P_LOS,T_c,t_end,r,lamda,f_d,C_channel);                 % Add LOS propagation to the first tap
%-------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check Results and plot channel figures
%Display results
t_plot=t(round(length(t)/2));
G=directivity_pattern(Channel_coeff,T_c,t_end,t_plot,r,B,f_c);               % Directivity pattern for certain time instant
G_p=directivity_polar(Channel_coeff,T_c,t_end,t_plot,r,f_c);                 % Gain of each path
ts_plot= t(1:(length(t)-1)/100:length(t));                                       % Vector containing time instants of the channel coefficients
G_t=directivity_time(Channel_coeff,T_c,t_end,ts_plot,r,B,f_c);              % Directivity patter for certain frequency
%-------------------------------------------------------
% Check Powers
% for i=1:L
%     Av_power_Y(i)=norm(Y(:,:,i),'fro').^2/(size(Y,2)*N_e);
%     Av_power_As(i)=norm(A_s(:,:,i),'fro').^2/(size(A_s,2)*N_e);
%     Av_power_Ac(i)=norm(A_c(:,:,i),'fro').^2/(size(A_c,2)*N_e);
%     Av_power_A(i)=norm(A(:,:,i),'fro').^2/(size(A,2)*N_e);
% end
F_a=(1-exp(-1/(B*T_m)))*exp(-(0:L-1)/(B*T_m));                 % Exponential power delay profile
F_a=F_a/norm(F_a,1);                                           % Power Normalization

