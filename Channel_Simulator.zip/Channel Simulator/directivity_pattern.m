% A function to plot the directivity pattern of a receiver matched to the
% simulated channel coefficients at a prespecified time instant

% Inputs  A_c    N_e X M*T_d/T_c X L matrix containing the upsampled channel coefficients
%         T_c    Sampling interval
%         t_end  Last time instant on the time axis
%         t      M*T_d/T_c vector containing the corresponding time instants
%         t_plot The time instant at which the pattern is plotted
%         r      location vector containing the locations of the array elements
%         B      Bandwidth
%         f_c    center frequency of the incident wave

% Output  G      N_theta X N_f matrix containing the directivity pattern
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function G=directivity_pattern(A_c,T_c,t_end,t_plot,r,B,f_c)

% Extract the channel coefficients at time t_plot
t=0:T_c:t_end;                                         % vector containing time instants of the channel coefficients
Index=find(t==t_plot);
[N_e,N,L]=size(A_c);
for k=1:L
    C(1:N_e,k)=A_c(:,Index,k);
end
%-------------------------------------------------------
% Construct the Pattern
w=vec((C));                                            % Beamforming vector matched to channel coefficients
w=w/norm(w);                                           % Normalize weight vector 
Theta_grid=linspace(0,360,181)*pi/180;                 % Angular grid used to plot the array response
f_grid=linspace(-B,B,100);                             % frequency grid used to plot the array response
c=3e8;                                                 % propagation speed of the wave
for i=1:length(Theta_grid)
    theta=Theta_grid(i);
    for f_ind=1:length(f_grid)
        f=f_grid(f_ind);
        K=2*pi*(f+f_c)*[cos(theta),sin(theta)]/c;       % wave vector (Passband frequency is used f+f_c)
        v=exp(-j*K*r.').';                                                                % Narrowband array steering vector (received by sensors)
        a=kron(exp(-j*2*pi*f*(0:L-1)*T_c).',v);        % Wideband steering vector
        a=a./norm(a);
        G(i,f_ind)=w'*a;
    end
end
%-------------------------------------------------------
% Plot the Directivity pattern image
figure
G_abs=20*log10(abs(G));                                 % Absolute value of the directivity pattern in decibels
% Plot the 2D image
colormap('gray');
G_image=G_abs;
% [I,J]=find(G_image<-50);
% G_image(I,J)=-50;
%imagesc(180*Theta_grid/pi,f_grid/(2*B),(G_image.'));
contourf(180*Theta_grid/pi,f_grid/(2*B),(G_image.'));
ylabel('Normalized frequency')
xlabel('Azimuth angle (degrees)')
colorbar('vert')


% Plot the Directivity pattern image
figure
G_abs=20*log10(abs(G));                                 % Absolute value of the directivity pattern in decibels
% Plot the 2D image
colormap('gray');
G_image=G_abs;
% [I,J]=find(G_image<-50);
% G_image(I,J)=-50;
imagesc(180*Theta_grid/pi,f_grid/(2*B),(G_image.'));
%contourf(180*Theta_grid/pi,f_grid/(2*B),(G_image.'));
ylabel('Normalized frequency')
xlabel('Azimuth angle (degrees)')
colorbar('vert')

        