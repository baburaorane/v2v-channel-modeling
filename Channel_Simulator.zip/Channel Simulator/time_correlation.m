% A function to generate N_e independent sequences with specific time autocorrelation
% function
% Inputs : N_e    Number of independent sequences
%          L      Number of TDP (taps in the FIR model)
%          f_d    The doppler frequency f_c*v/c
%          K      Order of the IIR time correlation filter
%          t_end  Last time instant on the time axis       

% Output : Y      N_e X M X L where the ith N_e X M matrix contains the sequences of the ith TDP as its rows
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Y=time_correlation(N_e,L,f_d,T_d,t_end)
% time-correlation filter parameters
K=5;                                     % order of the time correlation IIR filter                
N_f=256;                                 % Number of frequency points used to approximate the time correlation filter
M=round(t_end/T_d)+1;                         % length of each sequence
%-------------------------------------------------------
% Desired power spectral density
f=linspace(-1/(2*T_d),1/(2*T_d),N_f+1); % frequency grid
for i=1:length(f)                 
    if abs(f(i))<=f_d
        S(i)=2/(sqrt((2*pi*f_d*T_d).^2-(2*pi*f(i)*T_d).^2));
    else
        S(i)=0;
    end
end
%-------------------------------------------------------
% Design filter coeeficients
% [a_k,b_k]=Get_filter(S,K,f,T_d);
a_k=[1;1.7428;2.3339;1.34276;0.59552];
b_k=[0.71724;1.70502;2.25142;1.51287;0.53630];
%-------------------------------------------------------
% Perform the filtering operation  to temporally colour the noise sequences
for i=1:L
    v=(randn(N_e,M)+j*randn(N_e,M))/sqrt(2);                         % Generate the white noise sequences
    for k=1:N_e
        Y(k,:,i)=filter(b_k,a_k,v(k,:));
    end
end
%-------------------------------------------------------
% Normalize the average power of each path to be equal to unity
for i=1:L
    norm_s=norm(Y(:,:,i),'fro').^2/(N_e*M);        % Average power within each subpath
    Y(:,:,i)=Y(:,:,i)/sqrt(norm_s);
end
